/* eslint-disable react-native/no-inline-styles */
import React, {useState} from 'react';
import {Text, StyleSheet, View, TouchableOpacity} from 'react-native';
import {connect} from 'react-redux';
import {commonStyle as cs} from './../styles/common/styles';
import Icon from 'react-native-vector-icons/FontAwesome';
import ImagePicker from 'react-native-image-picker';

const ImageSelector = props => {};
const mapStateToProps = state => {
  return {};
};

export default connect(mapStateToProps)(ImageSelector);
