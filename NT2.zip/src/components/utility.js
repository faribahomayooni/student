export function showToast(text) {
  global.App.toast.show(text);
}
