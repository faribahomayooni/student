export default {
  primaryColor: '#5467FD',
  primaryButtonColor: '#5467fd',
  primaryGrayText: '#cac8c8',
  primaryTextColor: '#31455E',
  buttonSpacing: 8,
  borderRadius: 5,
  inputHeight: 51,
};
