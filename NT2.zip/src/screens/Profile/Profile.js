import React, {Component} from 'react';
import {connect} from 'react-redux';
import {View, Text, TextInput, ScrollView} from 'react-native';
import {commonStyle as cs} from '../../styles/common/styles';
import {Button} from '../../components/widgets';
import Icon from 'react-native-vector-icons/FontAwesome';
import Progress from './../../components/Progress';
import {apiActions} from '../../actions';

class Profile extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  componentDidMount() {
    const {dispatch} = this.props;
    dispatch(apiActions.loadStudentInfo());
  }
  render() {
    const {studentInfo} = this.props;
    console.log(studentInfo);
    return (
      <ScrollView>
        <View style={cs.mainContainer}>
          <View style={cs.profileInfo}>
            <Text>
              <Text style={cs.nameView}>
                {this.props.studentInfo !== undefined ? (
                  <Text style={cs.BoldProfileInfo}>
                    {this.props.studentInfo.firstname}
                  </Text>
                ) : null}
              </Text>
              <Text style={cs.RegularProfileInfo}>, je zit in groep </Text>
              <Text style={cs.colorProfileInfo}>VH_2019_B1.</Text>
            </Text>
            <Text>
              <Text style={cs.RegularProfileInfo}>
                Je volgt een <Text style={cs.colorProfileInfo}>B1 </Text>traject
                en je
              </Text>
            </Text>
            <Text>
              <Text style={cs.RegularProfileInfo}>
                docent is <Text style={cs.colorProfileInfo}>Jannie Make.</Text>
              </Text>
            </Text>
          </View>
          <View style={cs.ProfileBorderBottom} />
          <View>
            <Text style={cs.titlePresence}>Mijn aanwezigheid</Text>
          </View>
          <View style={{alignItems: 'center'}}>
            <Text style={cs.progressText}>
              <Text style={cs.nameView}>
                {this.props.studentInfo !== undefined ? (
                  <Text style={cs.BoldProfileInfo}>
                    {this.props.studentInfo.firstname}
                  </Text>
                ) : null}
              </Text>
              <Text style={cs.RegularProgressInfo}>, je bent</Text>
            </Text>
            <Progress />
            <Text style={cs.progressBottomText}> van de lessen</Text>
            <Text style={cs.progressBottomText}> aanwezig geweest.</Text>
          </View>
          <View style={cs.ProfileBorderBottom} />
          <View style={{marginTop: 15}}>
            <Text style={cs.settingText}>Hieronder kun je de </Text>
            <Text style={cs.settingText}>
              {' '}
              instellingen van de APP aanpassen
            </Text>
          </View>
          <View style={{marginTop: 0}}>
            <Button
              colorButton="#5467fd"
              name="INSTELLINGEN"
              onClick={() => {
                studentInfo && studentInfo !== undefined
                  ? this.props.navigation.navigate('ProfileSetting', {
                      mobile: studentInfo.FLD_PHONE_NUMBER1,
                      email: studentInfo.FLD_EMAIL,
                      firstname: studentInfo.FLD_FIRSTNAME,
                      lastname: studentInfo.FLD_LASTNAME,
                      password: studentInfo.FLD_PASSWORD,
                    })
                  : null;
              }}
            />
            <View style={cs.nextIconWrapper}>
              <Icon
                name="chevron-right"
                color="white"
                size={12}
                style={{marginLeft: 8, marginTop: 5}}
              />
            </View>
          </View>
          {/* <Footer navigation={this.props.navigation} activeTab={'Profile'} /> */}
        </View>
      </ScrollView>
    );
  }
}

const mapStateToProps = state => {
  return {
    studentInfo: state.api.studentInfo,
  };
};

export default connect(mapStateToProps)(Profile);
